import logo from './logo.svg';
import List from './Components/List';
import SaleChart from "./Components/SaleChart";
import './App.css';

function App() {
  return (
    <div className="App">
      <List/>
      <SaleChart />
    </div>
  );
}

export default App;
