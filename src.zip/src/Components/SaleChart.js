import Chart from 'chart.js/auto'
import { useState } from 'react';
import saleData from "./SaleData.json";

const SaleChart = () => {
  const [data, setData] = useState(saleData);
    new Chart(
        document.getElementById('acquisitions'),
        {
          type: 'line',
          data: data
        }
      );
    return(
        <div>
            <canvas id="okCanvas2" width="400" height="100">
                <p>Hello Fallback World</p>
            </canvas>
        </div>
    );
}

export default SaleChart;