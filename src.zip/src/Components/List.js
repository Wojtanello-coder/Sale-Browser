import Item from "./Item";
import axios from "axios";
import { useEffect, useState } from "react";
import data from "./Items.json";
import "./List.css";

const List = () => {
    const [games, setGames] = useState(data);

    const options = {
        method: 'GET',
        url: 'https://www.cheapshark.com/api/1.0/deals',
        params: {
            "sortBy": "Price",
            "limit": 1,
            "metacritic": 90
        },
        headers: {
        }
    };
    const dummy_options = {
      method: 'GET',
      url: 'https://localhost:5000/api',
      params: {
          "message": "hello"
      },
      headers: {

      }
    }
    useEffect(() => {
      axios.request(dummy_options)
        .then(function (response) {
          console.log(response.data);
        })
        .catch(function (error) {
          console.log(error);
        });
    }, []);
    // useEffect(() => {
    //   axios.request(options)
    //   .then(function (response) {
    //       console.log(response.data);
    //       setGames(response.data);})
    //   .catch(function (error) {
    //       console.error(error);
    //       alert(error);
    // })}, []);
    
    // console.log(games);
    return(
        <div className="list">
            {games.map((game, index) => (

                <Item className="item" key={index} data={game}/>
            ))}
        </div>
    );
}

export default List;